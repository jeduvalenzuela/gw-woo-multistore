jQuery(document).ready(function($) {
    
    // Aquí puedes agregar funcionalidad frontend si es necesaria
    // Por ejemplo: AJAX para paginación sin recargar página
    
    console.log('MSW Frontend JS loaded');

});